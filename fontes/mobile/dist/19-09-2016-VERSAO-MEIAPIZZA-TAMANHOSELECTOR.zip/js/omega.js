function position(posicao){
  location.href = posicao;
}
